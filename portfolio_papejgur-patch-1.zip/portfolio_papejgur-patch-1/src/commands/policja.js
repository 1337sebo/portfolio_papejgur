const { SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType } = require('discord.js');
const appConfig = require('../config');
const registry = require('../utils/registry');
const { RANKS, getRankIndex, getRankByIndex, getRankLabel } = require('../data/policeRanks');
const { requirePoliceRole, requireCommander, getRankKeyFromRoles } = require('../utils/police');
const { buildApplicationPanelEmbed } = require('../utils/embeds');
const { POLICE_EXAM_START_PREFIX, WRD_EXAM_START_PREFIX } = require('../interactions/constants');
const { POLICE_EXAM_QUESTION_COUNT } = require('../utils/policeExam');
const { WRD_EXAM_QUESTION_COUNT } = require('../utils/wrdExam');
const {
  buildSprawdzGraczaEmbed,
  buildMandatEmbed,
  buildGonionyEmbed,
  buildZawieszenieEmbed,
  buildSluzbaEmbed,
  buildRankingEmbed,
  buildAwansEmbed,
  buildCbspEmbed,
  buildSprawdzAutoEmbed,
} = require('../utils/policeEmbeds');

const builder = new SlashCommandBuilder()
  .setName('policja')
  .setDescription('System policyjny Emergency Hamburg RP');

builder.addSubcommand((sub) => {
  sub
    .setName('setup')
    .setDescription('Konfiguracja ról systemu policyjnego (można uruchamiać wielokrotnie, żeby dopisać kolejne rangi)');
  sub.addRoleOption((o) => o.setName('rola-policja').setDescription('Rola dająca dostęp do komend policyjnych').setRequired(true));
  sub.addRoleOption((o) => o.setName('rola-cbsp').setDescription('Opcjonalna rola specjalnej jednostki CBŚP').setRequired(false));
  // Wszystkie rangi sa opcjonalne - drabinka ma 21 stopni (za duzo, zeby
  // wypelnic w jednym wywolaniu), wiec /policja setup mozna uruchomic kilka
  // razy z rozna czescia rol za kazdym razem (patrz execute() - dopisuje,
  // a nie nadpisuje calej mapy rankRoleIds).
  RANKS.forEach((rank) => {
    sub.addRoleOption((o) =>
      o.setName(`ranga-${rank.key}`).setDescription(`Rola odpowiadająca randze: ${rank.label}`).setRequired(false)
    );
  });
  return sub;
});

builder.addSubcommand((sub) =>
  sub
    .setName('rekrutacja')
    .setDescription('Wysyła panel rekrutacji do Komendy Miejskiej Policji (KMP)')
    .addChannelOption((o) =>
      o
        .setName('kanal')
        .setDescription('Kanał, na który zostanie wysłany panel rekrutacji do KMP')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
        .setRequired(true)
    )
    .addChannelOption((o) =>
      o
        .setName('kategoria')
        .setDescription('Kategoria, w której będą tworzone kanały podań')
        .addChannelTypes(ChannelType.GuildCategory)
        .setRequired(true)
    )
    .addRoleOption((o) => o.setName('rola-obslugi').setDescription('Rola widząca podania i mogąca je rozpatrywać').setRequired(true))
    .addRoleOption((o) =>
      o.setName('ranga-po-akceptacji').setDescription('Opcjonalna rola nadawana automatycznie po przyjęciu do KMP').setRequired(false)
    )
);

builder.addSubcommand((sub) =>
  sub
    .setName('rekrutacja-wrd')
    .setDescription('Wysyła panel rekrutacji do Wydziału Ruchu Drogowego (WRD) w ramach KMP')
    .addChannelOption((o) =>
      o
        .setName('kanal')
        .setDescription('Kanał, na który zostanie wysłany panel rekrutacji do WRD')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
        .setRequired(true)
    )
    .addChannelOption((o) =>
      o
        .setName('kategoria')
        .setDescription('Kategoria, w której będą tworzone kanały podań')
        .addChannelTypes(ChannelType.GuildCategory)
        .setRequired(true)
    )
    .addRoleOption((o) => o.setName('rola-obslugi').setDescription('Rola widząca podania i mogąca je rozpatrywać').setRequired(true))
    .addRoleOption((o) =>
      o.setName('ranga-po-akceptacji').setDescription('Opcjonalna rola nadawana automatycznie po przyjęciu do WRD').setRequired(false)
    )
);

builder.addSubcommand((sub) =>
  sub
    .setName('sprawdz-gracza')
    .setDescription('Sprawdza pełny profil gracza po nicku Roblox (dowód, prawo jazdy, pojazdy, mandaty...)')
    .addStringOption((o) => o.setName('nick').setDescription('Nick Roblox gracza').setRequired(true))
);

builder.addSubcommand((sub) =>
  sub
    .setName('sprawdz-auto')
    .setDescription('Sprawdza, do kogo należy pojazd o podanym numerze rejestracyjnym')
    .addStringOption((o) => o.setName('rejestracja').setDescription('Numer rejestracyjny pojazdu').setRequired(true))
);

builder.addSubcommand((sub) =>
  sub
    .setName('mandat')
    .setDescription('Wystawia mandat graczowi')
    .addUserOption((o) => o.setName('gracz').setDescription('Ukarany gracz').setRequired(true))
    .addIntegerOption((o) => o.setName('kwota').setDescription('Kwota mandatu w zł').setMinValue(1).setRequired(true))
    .addIntegerOption((o) =>
      o
        .setName('punkty')
        .setDescription('Punkty karne za wykroczenie (jak w prawdziwym systemie, 1-15)')
        .setMinValue(1)
        .setMaxValue(15)
        .setRequired(true)
    )
    .addStringOption((o) => o.setName('powod').setDescription('Powód wystawienia mandatu').setRequired(true))
);

builder.addSubcommand((sub) =>
  sub
    .setName('goniony')
    .setDescription('Dodaje lub usuwa gracza z listy gończej')
    .addUserOption((o) => o.setName('gracz').setDescription('Gracz').setRequired(true))
    .addStringOption((o) =>
      o
        .setName('akcja')
        .setDescription('Dodaj do listy czy usuń po zatrzymaniu')
        .setRequired(true)
        .addChoices({ name: 'Dodaj (ogłoś poszukiwanie)', value: 'dodaj' }, { name: 'Usuń (zatrzymany)', value: 'usun' })
    )
    .addStringOption((o) => o.setName('powod').setDescription('Powód poszukiwania (wymagany przy dodawaniu)').setRequired(false))
);

builder.addSubcommand((sub) =>
  sub
    .setName('zawieszenie')
    .setDescription('Zawiesza lub przywraca prawo jazdy gracza')
    .addUserOption((o) => o.setName('gracz').setDescription('Gracz').setRequired(true))
    .addStringOption((o) =>
      o
        .setName('akcja')
        .setDescription('Zawieś czy przywróć uprawnienia')
        .setRequired(true)
        .addChoices({ name: 'Zawieś', value: 'zawiesz' }, { name: 'Przywróć', value: 'przywroc' })
    )
    .addStringOption((o) => o.setName('powod').setDescription('Powód zawieszenia (wymagany przy zawieszaniu)').setRequired(false))
);

builder.addSubcommand((sub) => sub.setName('sluzba').setDescription('Rozpoczyna lub kończy Twoją służbę (clock-in/out)'));

builder.addSubcommand((sub) => sub.setName('ranking').setDescription('Ranking aktywności służbowej funkcjonariuszy'));

builder.addSubcommand((sub) =>
  sub
    .setName('awans')
    .setDescription('Awansuje funkcjonariusza o jedną rangę')
    .addUserOption((o) => o.setName('gracz').setDescription('Funkcjonariusz').setRequired(true))
);

builder.addSubcommand((sub) =>
  sub
    .setName('degradacja')
    .setDescription('Degraduje funkcjonariusza o jedną rangę')
    .addUserOption((o) => o.setName('gracz').setDescription('Funkcjonariusz').setRequired(true))
);

builder.addSubcommand((sub) =>
  sub
    .setName('cbsp')
    .setDescription('Przydziela lub odbiera przynależność do CBŚP')
    .addUserOption((o) => o.setName('gracz').setDescription('Funkcjonariusz').setRequired(true))
    .addStringOption((o) =>
      o
        .setName('akcja')
        .setDescription('Dodaj czy usuń z CBŚP')
        .setRequired(true)
        .addChoices({ name: 'Dodaj', value: 'dodaj' }, { name: 'Usuń', value: 'usun' })
    )
);

async function changeRank(interaction, config, direction) {
  if (!(await requireCommander(interaction, config))) return;

  const target = interaction.options.getUser('gracz');
  const targetMember = await interaction.guild.members.fetch(target.id).catch(() => null);
  if (!targetMember) {
    await interaction.reply({ content: '❌ Nie znaleziono tego gracza na serwerze.', ephemeral: true });
    return;
  }

  if (Object.values(config.rankRoleIds || {}).filter(Boolean).length === 0) {
    await interaction.reply({ content: '⚠️ Drabinka rang nie jest skonfigurowana — użyj najpierw `/policja setup`.', ephemeral: true });
    return;
  }

  const currentKey = registry.getRank(target.id) || getRankKeyFromRoles(targetMember, config.rankRoleIds);
  const currentIndex = currentKey ? getRankIndex(currentKey) : -1;
  const newIndex = currentIndex + direction;

  if (newIndex < 0) {
    await interaction.reply({ content: '❌ Ten gracz nie ma jeszcze żadnej rangi — użyj awansu, aby nadać pierwszą.', ephemeral: true });
    return;
  }
  if (newIndex >= RANKS.length) {
    await interaction.reply({ content: `❌ ${target} ma już najwyższą rangę (${getRankLabel(RANKS[RANKS.length - 1].key)}).`, ephemeral: true });
    return;
  }

  const newRank = getRankByIndex(newIndex);
  const newRoleId = config.rankRoleIds[newRank.key];
  if (!newRoleId) {
    await interaction.reply({ content: `⚠️ Rola dla rangi **${newRank.label}** nie jest skonfigurowana — użyj \`/policja setup\`.`, ephemeral: true });
    return;
  }

  try {
    if (currentKey && config.rankRoleIds[currentKey]) {
      await targetMember.roles.remove(config.rankRoleIds[currentKey]).catch(() => {});
    }
    await targetMember.roles.add(newRoleId);
  } catch (error) {
    console.error('Błąd podczas zmiany roli rangi:', error);
    await interaction.reply({ content: '❌ Nie udało się zmienić roli — sprawdź uprawnienia bota (Manage Roles) i hierarchię ról.', ephemeral: true });
    return;
  }

  registry.setRank(target.id, target.tag, newRank.key);

  const embed = buildAwansEmbed({
    officer: interaction.user,
    target: targetMember,
    action: direction > 0 ? 'awans' : 'degradacja',
    newRankLabel: newRank.label,
  });
  await interaction.reply({ embeds: [embed] });
}

module.exports = {
  data: builder,

  async execute(interaction) {
    if (interaction.guildId !== appConfig.policeGuildId) {
      await interaction.reply({
        content: '❌ System policyjny (`/policja`) jest dostępny tylko na głównym serwerze Emergency Hamburg RP.',
        ephemeral: true,
      });
      return;
    }

    const subcommand = interaction.options.getSubcommand();
    const config = registry.getConfig();

    if (subcommand === 'rekrutacja') {
      const channel = interaction.options.getChannel('kanal');
      const category = interaction.options.getChannel('kategoria');
      const supportRole = interaction.options.getRole('rola-obslugi');
      const acceptRole = interaction.options.getRole('ranga-po-akceptacji');

      const panelId = registry.savePoliceRecruitmentPanel({
        categoryId: category.id,
        supportRoleId: supportRole.id,
        acceptRoleId: acceptRole ? acceptRole.id : null,
      });

      const embed = buildApplicationPanelEmbed(supportRole, {
        title: '🚓 Panel — Rekrutacja do KMP',
        extraLine:
          `Ta rekrutacja dotyczy dołączenia do **Komendy Miejskiej Policji (KMP)**. Zanim napiszesz podanie, ` +
          `musisz najpierw zdać **egzamin wiedzy** (${POLICE_EXAM_QUESTION_COUNT} trudnych pytań, dopuszczalna tylko 1 pomyłka).`,
      });
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`${POLICE_EXAM_START_PREFIX}:${panelId}`)
          .setLabel('Podejdź do rekrutacji')
          .setEmoji('🚓')
          .setStyle(ButtonStyle.Primary)
      );

      try {
        await channel.send({ embeds: [embed], components: [row] });
      } catch (error) {
        console.error('Błąd podczas wysyłania panelu rekrutacji do KMP:', error);
        await interaction.reply({
          content: `❌ Nie udało się wysłać panelu na ${channel}. Sprawdź, czy bot ma tam uprawnienia do wysyłania wiadomości.`,
          ephemeral: true,
        });
        return;
      }

      await interaction.reply({ content: `✅ Panel rekrutacji do KMP wysłany na ${channel}.`, ephemeral: true });
      return;
    }

    if (subcommand === 'rekrutacja-wrd') {
      const channel = interaction.options.getChannel('kanal');
      const category = interaction.options.getChannel('kategoria');
      const supportRole = interaction.options.getRole('rola-obslugi');
      const acceptRole = interaction.options.getRole('ranga-po-akceptacji');

      const panelId = registry.savePoliceRecruitmentPanel({
        categoryId: category.id,
        supportRoleId: supportRole.id,
        acceptRoleId: acceptRole ? acceptRole.id : null,
      });

      const embed = buildApplicationPanelEmbed(supportRole, {
        title: '🚦 Panel — Rekrutacja do WRD',
        extraLine:
          `Ta rekrutacja dotyczy dołączenia do **Wydziału Ruchu Drogowego (WRD)** w ramach KMP. Zanim napiszesz ` +
          `podanie, musisz najpierw zdać **egzamin podstawowy** (${WRD_EXAM_QUESTION_COUNT} pytań o ruchu drogowym, dopuszczalne 2 pomyłki).`,
      });
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`${WRD_EXAM_START_PREFIX}:${panelId}`)
          .setLabel('Podejdź do rekrutacji')
          .setEmoji('🚦')
          .setStyle(ButtonStyle.Primary)
      );

      try {
        await channel.send({ embeds: [embed], components: [row] });
      } catch (error) {
        console.error('Błąd podczas wysyłania panelu rekrutacji do WRD:', error);
        await interaction.reply({
          content: `❌ Nie udało się wysłać panelu na ${channel}. Sprawdź, czy bot ma tam uprawnienia do wysyłania wiadomości.`,
          ephemeral: true,
        });
        return;
      }

      await interaction.reply({ content: `✅ Panel rekrutacji do WRD wysłany na ${channel}.`, ephemeral: true });
      return;
    }

    if (subcommand === 'setup') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        await interaction.reply({ content: '❌ Ta komenda wymaga uprawnień Zarządzaj Serwerem.', ephemeral: true });
        return;
      }

      const policeRoleId = interaction.options.getRole('rola-policja').id;
      const cbspRole = interaction.options.getRole('rola-cbsp');

      // Dopisujemy tylko podane teraz rangi, nie kasujac tych ustawionych
      // wczesniejszym wywolaniem - drabinka ma 21 stopni, wiec zwykle trzeba
      // uzupelniac ja na kilka razy.
      const newRankRoleIds = {};
      RANKS.forEach((rank) => {
        const role = interaction.options.getRole(`ranga-${rank.key}`);
        if (role) newRankRoleIds[rank.key] = role.id;
      });
      const mergedRankRoleIds = { ...config.rankRoleIds, ...newRankRoleIds };

      registry.setConfig({
        policeRoleId,
        cbspRoleId: cbspRole ? cbspRole.id : config.cbspRoleId,
        rankRoleIds: mergedRankRoleIds,
      });

      const rankLines = RANKS.map((rank) => {
        const roleId = mergedRankRoleIds[rank.key];
        return `• ${rank.label}: ${roleId ? `<@&${roleId}>` : '⚠️ nieskonfigurowana'}`;
      }).join('\n');

      await interaction.reply({
        content:
          `✅ System policyjny skonfigurowany.\n\n` +
          `**Rola dostępu:** <@&${policeRoleId}>\n` +
          `**CBŚP:** ${cbspRole ? `<@&${cbspRole.id}>` : config.cbspRoleId ? `<@&${config.cbspRoleId}>` : 'nie skonfigurowano'}\n\n` +
          `**Drabinka rang:**\n${rankLines}\n\n` +
          `ℹ️ Możesz uruchomić \`/policja setup\` ponownie, żeby dopisać kolejne rangi — te już ustawione zostaną zachowane.`,
        ephemeral: true,
      });
      return;
    }

    if (subcommand === 'sprawdz-gracza') {
      if (!(await requirePoliceRole(interaction, config))) return;

      const nick = interaction.options.getString('nick');
      const discordId = registry.findDiscordIdByRobloxNick(nick);
      const record = discordId ? registry.getUserRecord(discordId) : null;
      const activePoints = discordId ? registry.getActivePoints(discordId) : 0;

      const embed = buildSprawdzGraczaEmbed({ nick, discordId, record, activePoints });
      await interaction.reply({ embeds: [embed] });
      return;
    }

    if (subcommand === 'sprawdz-auto') {
      if (!(await requirePoliceRole(interaction, config))) return;

      const plateNumber = interaction.options.getString('rejestracja');
      const found = registry.findVehicleByPlate(plateNumber);

      const embed = buildSprawdzAutoEmbed({
        plateNumber,
        discordId: found ? found.discordId : null,
        discordTag: found ? found.discordTag : null,
        vehicle: found ? found.vehicle : null,
      });
      await interaction.reply({ embeds: [embed] });
      return;
    }

    if (subcommand === 'mandat') {
      if (!(await requirePoliceRole(interaction, config))) return;

      const target = interaction.options.getUser('gracz');
      const amount = interaction.options.getInteger('kwota');
      const points = interaction.options.getInteger('punkty');
      const reason = interaction.options.getString('powod');

      const { activePoints, autoSuspended } = registry.addCitation(target.id, target.tag, {
        reason,
        amount,
        points,
        issuedBy: interaction.user.id,
        issuedByTag: interaction.user.tag,
      });

      const embed = buildMandatEmbed({ officer: interaction.user, target, amount, points, reason, activePoints, autoSuspended });
      await interaction.reply({ embeds: [embed] });
      return;
    }

    if (subcommand === 'goniony') {
      if (!(await requirePoliceRole(interaction, config))) return;

      const target = interaction.options.getUser('gracz');
      const action = interaction.options.getString('akcja');
      const reason = interaction.options.getString('powod');

      if (action === 'dodaj') {
        if (!reason) {
          await interaction.reply({ content: '⚠️ Podaj powód poszukiwania (opcja `powod`).', ephemeral: true });
          return;
        }
        registry.setWanted(target.id, target.tag, { reason, issuedBy: interaction.user.id, issuedByTag: interaction.user.tag });
      } else {
        const removed = registry.clearWanted(target.id);
        if (!removed) {
          await interaction.reply({ content: `ℹ️ ${target} nie był poszukiwany.`, ephemeral: true });
          return;
        }
      }

      const embed = buildGonionyEmbed({ officer: interaction.user, target, action, reason });
      await interaction.reply({ embeds: [embed] });
      return;
    }

    if (subcommand === 'zawieszenie') {
      if (!(await requirePoliceRole(interaction, config))) return;

      const target = interaction.options.getUser('gracz');
      const action = interaction.options.getString('akcja');
      const reason = interaction.options.getString('powod');
      const suspend = action === 'zawiesz';

      if (suspend && !reason) {
        await interaction.reply({ content: '⚠️ Podaj powód zawieszenia (opcja `powod`).', ephemeral: true });
        return;
      }

      registry.setLicenseSuspended(target.id, target.tag, suspend, {
        reason,
        issuedBy: interaction.user.id,
        issuedByTag: interaction.user.tag,
      });

      const embed = buildZawieszenieEmbed({ officer: interaction.user, target, action, reason });
      await interaction.reply({ embeds: [embed] });
      return;
    }

    if (subcommand === 'sluzba') {
      if (!(await requirePoliceRole(interaction, config))) return;

      const status = registry.getDutyStatus(interaction.user.id);

      if (!status.onDuty) {
        registry.startDuty(interaction.user.id, interaction.user.tag);
        const embed = buildSluzbaEmbed({ officer: interaction.user, started: true });
        await interaction.reply({ embeds: [embed] });
      } else {
        const result = registry.endDuty(interaction.user.id, interaction.user.tag);
        const embed = buildSluzbaEmbed({ officer: interaction.user, started: false, durationMs: result.durationMs });
        await interaction.reply({ embeds: [embed] });
      }
      return;
    }

    if (subcommand === 'ranking') {
      const ranking = registry.getDutyRanking(10);
      const embed = buildRankingEmbed(ranking);
      await interaction.reply({ embeds: [embed] });
      return;
    }

    if (subcommand === 'awans') {
      await changeRank(interaction, config, 1);
      return;
    }

    if (subcommand === 'degradacja') {
      await changeRank(interaction, config, -1);
      return;
    }

    if (subcommand === 'cbsp') {
      if (!(await requireCommander(interaction, config))) return;

      const target = interaction.options.getUser('gracz');
      const action = interaction.options.getString('akcja');
      const targetMember = await interaction.guild.members.fetch(target.id).catch(() => null);
      const add = action === 'dodaj';

      if (config.cbspRoleId && targetMember) {
        try {
          if (add) {
            await targetMember.roles.add(config.cbspRoleId);
          } else {
            await targetMember.roles.remove(config.cbspRoleId);
          }
        } catch (error) {
          console.error('Błąd podczas zmiany roli CBŚP:', error);
        }
      }

      registry.setCbsp(target.id, target.tag, add);

      const embed = buildCbspEmbed({ officer: interaction.user, target, action });
      await interaction.reply({ embeds: [embed] });
    }
  },
};
